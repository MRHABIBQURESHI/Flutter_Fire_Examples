package com.example.nov20

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
