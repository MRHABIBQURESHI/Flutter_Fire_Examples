import 'package:screen/model/data.dart';

List<imf> data = [
  imf(Name: "Name 1", age: 4),
  imf(Name: "Name 2", age: 14),
  imf(Name: "Name 3", age: 24),
];
