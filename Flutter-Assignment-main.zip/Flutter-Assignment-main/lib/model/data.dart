class imf {
  String Name;
  int age;

  imf({
    required this.Name,
     required this.age,
  });
  
}