// import 'dart:math';

// void main()
// {
//   Map student = {

//     "name" : "Habib",
//     "Class" : 12

//   };
//   // print(student);
//   // print(student["name"]);
//     // print(student.isEmpty);
//       // print(student.keys);
//         // print(student.putIfAbsent("Class", () => 13));
//           // print(student.remove("Class"));
//             // print(student["age"] = 17);
            
//   print(student);
//   print(student["name"]);
//     print(student.isEmpty);
//       print(student.keys);
//         print(student.putIfAbsent("Class", () => 13));
//           print(student.remove("Class"));
//             print(student["age"] = 17);
//             print(student);


//             // Erthmetic Oprator

//             print(1 + 2);
//             print(1 - 2);
//             print(1 * 2);
//             print(1 / 2);
//             print(1 % 2);
//             print(1 == 2);
//             print(1 < 2);
//             print(1 > 2);

//             print(1 == 2);
//             print(1 <= 2);
//             print(1 >= 2);
//             print(1 != 2);
             
//             print(true && true);
//             print(false && true);
//             print(true && false);
//             print(false && false);
                    
//             print(true  || true);
//             print(false || true);
//             print(true || false);
//             print(false|| false);


          
// // Map Per = {

// //     "Englsih" : 50,
// //     "Urdu" : 12,
// //     "Computer" : 68,
// //     "Math" : 45,
// //     "obtmarks" : 175,
// //     "total" : 400,


  

// //   };
// //     print(Per["total"] / 100 * 175 );

// var Per = 100; 

//     if(Per >= 90)
//     {
//       print("You are Frist");
//     } else if (Per >= 80)
//     {
//       print("you ARE 2 ");
//     } else if (Per >= 70)
//     {
//       print("Your are  3");
//     }else if (Per >= 65)
//     {
//       print("Your are pass");
//     }
    
//     else if (Per >= 50)
//     {
//       print("Your are only pass");
//     }else{
//       print("you are fail");
//     }
    

// List <String> ary = ["a" , "b" , "c" , "d" , "e"];

//   for (var i = 0; i < ary.length; i++) 
//   {

//     print(ary[i]);
    
//   }


// List <String> ay = ["a" , "b" , "c" , "d" , "e"];

//   for (var i = 1; i <= ary.length; i++) 
//   {

//     print(ay[i-1]);
    
//   }

// }




// import 'dart:io';

// import 'dart:io';

// void main()

// {
  
//   var input = stdin.readLineSync();
//   print(input);
//   while(input!.length != 5 )
//   {
//     input = stdin.readLineSync();
//     // print(input.runtimeType);
//  }

  // var Name = stdin.readLineSync();
  // var Class = stdin.readLineSync();
  // var Age = stdin.readLineSync();
  // var Gender = stdin.readLineSync();

  // Map student = {

  //   "Your Name" : Name,
  //    "Your Class" : Class,
  //    "Your Age" : Age,
  //    "Your Gender" : Gender,

  // };
  // print(student);
  

 
//  List <Map> student = [];
// for (var a = 0; a <10 ; a++)
// {
//   print("student ${a + 1}");
//    var Name = stdin.readLineSync();
//    var Class = stdin.readLineSync();
//    var Age = stdin.readLineSync();
//    var Gender = stdin.readLineSync();



//   Map Loop = {

//   "Your Name" : Name,
//       "Your Class" : Class,
//     "Your Age" : Age,
//   "Your Gender" : Gender,

// };
// student.add(Loop);
// }
// print(student);




// List abc = [];
// abc.fillRange(1, 7);    

// var a = 12;
// var b = 56;

// a.toString();

// // call in string varriable '$'

// print("hellow world $a");

// print("hellow world ${a+55}");







// addd(int a , int b)
// {
// return (a + b);
// }

// var e = addd(5 , 5);
// print(e);



// addd(int? a , int? b)
// {
//   int x = a ?? 0;
//   int y = b ?? 0;
// return (x +  y);
// }

// var e = addd(5 , 5);
// print(e);






// addd({required int a , required int b})
// {
  
// return (a +  b);
// }

// var e = addd(a :5 , b : 5);
// print(e);




// ignore: unused_element


// }

//  calculategrade()
// {
//   print("Enter Percentage");
//      var p = stdin.readLineSync();
      


// }
